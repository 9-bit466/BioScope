
20/storage/emulated/0/CodeOnTheGoProjects/BioScope1794053411687"�
app/build.gradle.ktsE/storage/emulated/0/CodeOnTheGoProjects/BioScope/app/build.gradle.kts�% �����4*@ee3690f7dfc261fb466f9adf802013955f6ae91fb9a6d4ca60c69a29fa2f7ac6"�
build.gradle.ktsA/storage/emulated/0/CodeOnTheGoProjects/BioScope/build.gradle.kts� �����4*@894c92aa66d7ae56d21573617b028f15675252935e41e9fd8165c4b41cec3d37"�
gradle.propertiesB/storage/emulated/0/CodeOnTheGoProjects/BioScope/gradle.properties�
 �����4*@194f9064020d41d27decd9e74375ff1459b75854f0d68f38e0375ca3b4f031b4"�
(gradle/wrapper/gradle-wrapper.propertiesY/storage/emulated/0/CodeOnTheGoProjects/BioScope/gradle/wrapper/gradle-wrapper.properties� �����4*@80dbd23007872ba453e1dcc698121d3c18d71e937a413f7543761a6d4ce93e40"�
settings.gradle.ktsD/storage/emulated/0/CodeOnTheGoProjects/BioScope/settings.gradle.kts� �����4*@55562394f2d93c9acee8b30bdfa6d736319046df7167b6becedafc2fa5f79744*�
K/storage/emulated/0/CodeOnTheGoProjects/BioScope/.cg/gradle-sync/project.pb@7ea3c1c64769fdd59b6b789847bdf19659c225d68064f102615b9cb7727e4dbc