package com.bioscope.app;

interface ILogcatService {
    String[] readRecentRobloxLogs(int maxLines);
    String[] readNewRobloxLogs();
}
