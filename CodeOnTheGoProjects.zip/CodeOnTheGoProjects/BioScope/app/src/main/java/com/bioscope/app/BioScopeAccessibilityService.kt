
package com.bioscope.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.hardware.HardwareBuffer
import android.os.Build
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class BioScopeAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BioScopeAccessibilityService? = null
            private set
    }

    data class ScreenText(
        val text: String,
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int
    )

    private data class GreenAnalysis(
        val count: Int,
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int,
        val centerX: Int,
        val centerY: Int
    )

    private lateinit var recognizer: TextRecognizer
    private lateinit var screenshotExecutor: ExecutorService

    @Volatile
    private var gestureRunning = false

    override fun onCreate() {
        super.onCreate()

        recognizer = TextRecognition.getClient(
            TextRecognizerOptions.DEFAULT_OPTIONS
        )

        screenshotExecutor = Executors.newSingleThreadExecutor()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d("BioScopeTouch", "Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        gestureRunning = false
        Log.d("BioScopeTouch", "Service interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    // =====================================================
    // TOQUE SIMPLES
    // =====================================================

    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply {
            moveTo(x, y)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    0,
                    100
                )
            )
            .build()

        return dispatchGesture(gesture, null, null)
    }

    // =====================================================
    // TOQUE COM DURACAO PERSONALIZADA
    // =====================================================

    fun hold(
        x: Float,
        y: Float,
        duration: Long,
        onFinished: ((Boolean) -> Unit)? = null
    ): Boolean {

        val path = Path().apply {
            moveTo(x, y)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    0,
                    duration.coerceIn(100L, 60000L)
                )
            )
            .build()

        return dispatchGesture(
            gesture,
            object : GestureResultCallback() {

                override fun onCompleted(
                    gestureDescription: GestureDescription
                ) {
                    gestureRunning = false
                    onFinished?.invoke(true)
                }

                override fun onCancelled(
                    gestureDescription: GestureDescription
                ) {
                    gestureRunning = false
                    onFinished?.invoke(false)
                }
            },
            null
        )
    }

    // =====================================================
    // TOQUE CONTINUO COM CONTROLE DE PRESSAO
    // =====================================================

    fun startHold(
        x: Float,
        y: Float,
        duration: Long,
        onFinished: ((Boolean) -> Unit)? = null
    ): Boolean {

        if (gestureRunning) return false

        gestureRunning = true

        val path = Path().apply {
            moveTo(x, y)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    0,
                    duration.coerceIn(100L, 60000L)
                )
            )
            .build()

        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {

                override fun onCompleted(
                    gestureDescription: GestureDescription
                ) {
                    gestureRunning = false
                    Log.d("BioScopeTouch", "Hold completed")
                    onFinished?.invoke(true)
                }

                override fun onCancelled(
                    gestureDescription: GestureDescription
                ) {
                    gestureRunning = false
                    Log.d("BioScopeTouch", "Hold cancelled")
                    onFinished?.invoke(false)
                }
            },
            null
        )

        if (!accepted) {
            gestureRunning = false
        }

        return accepted
    }

    // =====================================================
    // JOYSTICK
    // =====================================================

    fun moveJoystick(
        targetX: Float,
        targetY: Float,
        duration: Long,
        onFinished: (Boolean) -> Unit
    ): Boolean {

        val path = Path().apply {
            moveTo(176f, 638f)
            lineTo(targetX, targetY)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    0,
                    duration.coerceAtLeast(100L)
                )
            )
            .build()

        return dispatchGesture(
            gesture,
            object : GestureResultCallback() {

                override fun onCompleted(
                    gestureDescription: GestureDescription
                ) {
                    Log.d(
                        "BioScopeTouch",
                        "Joystick movement completed"
                    )
                    onFinished(true)
                }

                override fun onCancelled(
                    gestureDescription: GestureDescription
                ) {
                    Log.d(
                        "BioScopeTouch",
                        "Joystick movement cancelled"
                    )
                    onFinished(false)
                }
            },
            null
        )
    }

    // =====================================================
    // OCR
    // =====================================================

    fun recognizeScreen(
        onResult: (List<ScreenText>) -> Unit,
        onError: (String) -> Unit
    ) {
        captureScreen(
            onBitmap = { bitmap ->
                recognizeBitmap(bitmap, onResult, onError)
            },
            onError = onError
        )
    }

    private fun recognizeBitmap(
        bitmap: Bitmap,
        onResult: (List<ScreenText>) -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            val image = InputImage.fromBitmap(bitmap, 0)

            recognizer.process(image)
                .addOnSuccessListener { result ->

                    val detectedTexts = mutableListOf<ScreenText>()

                    for (block in result.textBlocks) {
                        for (line in block.lines) {
                            val bounds = line.boundingBox ?: continue

                            detectedTexts.add(
                                ScreenText(
                                    line.text,
                                    bounds.left,
                                    bounds.top,
                                    bounds.right,
                                    bounds.bottom
                                )
                            )
                        }
                    }

                    detectedTexts.forEach {
                        Log.d(
                            "BioScopeVision",
                            "${it.text} | ${it.left},${it.top},${it.right},${it.bottom}"
                        )
                    }

                    onResult(detectedTexts)
                }
                .addOnFailureListener { error ->
                    onError(
                        error.message ?: "OCR processing failed."
                    )
                }
                .addOnCompleteListener {
                    if (!bitmap.isRecycled) bitmap.recycle()
                }

        } catch (error: Exception) {
            if (!bitmap.isRecycled) bitmap.recycle()

            onError(
                error.message ?: "OCR processing failed."
            )
        }
    }

    // =====================================================
    // DIAGNOSTICO VISUAL
    // Mantido para compatibilidade com o FloatingButtonService
    // =====================================================

    fun diagnoseScreen(
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        captureScreen(
            onBitmap = { bitmap ->

                try {
                    val green = analyzeGreenPixels(bitmap)

                    val report = StringBuilder()

                    report.appendLine(
                        "SCREEN: ${bitmap.width}x${bitmap.height}"
                    )

                    report.appendLine(
                        "GREEN PIXELS: ${green.count}"
                    )

                    if (green.count > 0) {
                        report.appendLine(
                            "GREEN BOUNDS: ${green.left},${green.top},${green.right},${green.bottom}"
                        )
                    }

                    val image = InputImage.fromBitmap(bitmap, 0)

                    recognizer.process(image)
                        .addOnSuccessListener { result ->

                            for (block in result.textBlocks) {
                                for (line in block.lines) {
                                    val bounds = line.boundingBox ?: continue

                                    report.appendLine(
                                        "TEXT: ${line.text} | ${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"
                                    )
                                }
                            }

                            onResult(report.toString())
                        }
                        .addOnFailureListener { error ->
                            onError(
                                error.message ?: "Diagnostic OCR failed."
                            )
                        }
                        .addOnCompleteListener {
                            if (!bitmap.isRecycled) bitmap.recycle()
                        }

                } catch (error: Exception) {
                    if (!bitmap.isRecycled) bitmap.recycle()

                    onError(
                        error.message ?: "Visual diagnosis failed."
                    )
                }
            },
            onError = onError
        )
    }

    // =====================================================
    // ANALISE DE PIXELS VERDES
    // =====================================================

    private fun analyzeGreenPixels(bitmap: Bitmap): GreenAnalysis {

        val step = 2

        var count = 0
        var minX = bitmap.width
        var minY = bitmap.height
        var maxX = 0
        var maxY = 0

        var totalX = 0L
        var totalY = 0L

        var y = 0

        while (y < bitmap.height) {
            var x = 0

            while (x < bitmap.width) {

                val pixel = bitmap.getPixel(x, y)

                val red = android.graphics.Color.red(pixel)
                val green = android.graphics.Color.green(pixel)
                val blue = android.graphics.Color.blue(pixel)

                val isGreen =
                    green > 110 &&
                    green > red * 1.25 &&
                    green > blue * 1.10

                if (isGreen) {
                    count++

                    minX = minOf(minX, x)
                    minY = minOf(minY, y)
                    maxX = maxOf(maxX, x)
                    maxY = maxOf(maxY, y)

                    totalX += x
                    totalY += y
                }

                x += step
            }

            y += step
        }

        if (count == 0) {
            return GreenAnalysis(
                0, 0, 0, 0, 0, 0, 0
            )
        }

        return GreenAnalysis(
            count,
            minX,
            minY,
            maxX,
            maxY,
            (totalX / count).toInt(),
            (totalY / count).toInt()
        )
    }

    // =====================================================
    // CAPTURA DE TELA
    // =====================================================

    private fun captureScreen(
        onBitmap: (Bitmap) -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            onError("Screen recognition requires Android 11 or newer.")
            return
        }

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            screenshotExecutor,
            object : TakeScreenshotCallback {

                override fun onSuccess(
                    screenshot: ScreenshotResult
                ) {
                    var hardwareBitmap: Bitmap? = null
                    var screenBitmap: Bitmap? = null

                    val buffer: HardwareBuffer =
                        screenshot.hardwareBuffer

                    try {
                        hardwareBitmap = Bitmap.wrapHardwareBuffer(
                            buffer,
                            screenshot.colorSpace
                        )

                        if (hardwareBitmap == null) {
                            onError("Could not create screenshot bitmap.")
                            return
                        }

                        screenBitmap = hardwareBitmap.copy(
                            Bitmap.Config.ARGB_8888,
                            false
                        )

                        if (screenBitmap == null) {
                            onError("Could not convert screenshot.")
                            return
                        }

                        onBitmap(screenBitmap)
                        screenBitmap = null

                    } catch (error: Exception) {
                        screenBitmap?.recycle()

                        onError(
                            error.message ?: "Screenshot capture failed."
                        )
                    } finally {
                        hardwareBitmap?.recycle()
                        buffer.close()
                    }
                }

                override fun onFailure(errorCode: Int) {
                    Log.e(
                        "BioScopeVision",
                        "Screenshot failed: $errorCode"
                    )

                    onError(
                        "Screenshot failed. Error code: $errorCode"
                    )
                }
            }
        )
    }

    // =====================================================
    // CICLO DE VIDA
    // =====================================================

    override fun onDestroy() {
        if (instance === this) instance = null

        gestureRunning = false

        if (::recognizer.isInitialized) {
            recognizer.close()
        }

        if (::screenshotExecutor.isInitialized) {
            screenshotExecutor.shutdown()
        }

        super.onDestroy()
    }
}
