package com.bioscope.app

import org.json.JSONObject

data class DetectedBiome(
    val name: String,
    val assetId: Long?
)

object BiomeDetector {

    fun detectBiomeInfo(log: String): DetectedBiome? {
        return try {
            val marker = "[BloxstrapRPC]"
            val markerIndex = log.indexOf(marker)

            if (markerIndex == -1) return null

            val jsonStart = log.indexOf("{", markerIndex)

            if (jsonStart == -1) return null

            val jsonText = extractJsonObject(log, jsonStart)
                ?: return null

            val json = JSONObject(jsonText)

            if (json.optString("command") != "SetRichPresence") {
                return null
            }

            val data = json.optJSONObject("data")
                ?: return null

            val largeImage = data.optJSONObject("largeImage")
                ?: return null

            val biome = largeImage
                .optString("hoverText")
                .trim()

            if (biome.isBlank()) {
                return null
            }

            val assetIdValue = largeImage.optLong("assetId", 0L)

            DetectedBiome(
                name = biome,
                assetId = assetIdValue.takeIf { it > 0L }
            )

        } catch (e: Exception) {
            null
        }
    }

    // Mantém compatibilidade com o detector antigo.
    fun detectBiome(log: String): String? {
        return detectBiomeInfo(log)?.name
    }

    private fun extractJsonObject(
        text: String,
        start: Int
    ): String? {

        var depth = 0
        var insideString = false
        var escaped = false

        for (i in start until text.length) {
            val char = text[i]

            if (insideString) {
                if (escaped) {
                    escaped = false
                } else if (char == '\\') {
                    escaped = true
                } else if (char == '"') {
                    insideString = false
                }
                continue
            }

            when (char) {
                '"' -> insideString = true

                '{' -> depth++

                '}' -> {
                    depth--

                    if (depth == 0) {
                        return text.substring(start, i + 1)
                    }
                }
            }
        }

        return null
    }
}
