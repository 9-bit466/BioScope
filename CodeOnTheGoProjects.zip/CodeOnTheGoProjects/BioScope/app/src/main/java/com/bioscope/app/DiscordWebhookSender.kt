 package com.bioscope.app

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.util.Locale
import java.util.concurrent.Executors

class DiscordWebhookSender(context: Context) {

    private val preferences = context.applicationContext
        .getSharedPreferences(
            "bioscope_macro_config",
            Context.MODE_PRIVATE
        )

    private val executor = Executors.newSingleThreadExecutor()

    companion object {
        private const val TAG = "BioScopeWebhook"
        private const val FOOTER = "BioScope | Release v1.0.0"
    }

    private val biomeColors = mapOf(
        "NORMAL" to 0x777777,
        "WINDY" to 0x176B49,
        "SAND STORM" to 0xA58A69,
        "LOST FOREST" to 0x087B35,
        "HEAVEN" to 0xB9A77E,
        "CORRUPTION" to 0x4820A0,
        "SNOWY" to 0x8495A5,
        "HELL" to 0x8D100D,
        "NULL" to 0x777777,
        "RAINY" to 0x164C9B,
        "STARFALL" to 0x0755D5,
        "DREAMSPACE" to 0xD64AAE,
        "CYBERSPACE" to 0x075BCB,
        "GLITCHED" to 0x39BDEB,
        "SINGULARITY" to 0xD94A27,
        "RADIANT FOREST" to 0x6636A9
    )

    fun sendBiomeStarted(biome: DetectedBiome) {
        sendNotification(
            event = "Started",
            biome = biome
        )
    }

    fun sendBiomeEnded(biome: DetectedBiome) {
        sendNotification(
            event = "Ended",
            biome = biome
        )
    }

    private fun sendNotification(
        event: String,
        biome: DetectedBiome
    ) {
        executor.execute {

            val webhook = preferences
                .getString("webhook", null)
                ?.trim()

            if (webhook.isNullOrBlank()) {
                Log.e(TAG, "Webhook is not configured.")
                return@execute
            }

            if (
                !webhook.startsWith(
                    "https://discord.com/api/webhooks/"
                ) &&
                !webhook.startsWith(
                    "https://discordapp.com/api/webhooks/"
                )
            ) {
                Log.e(TAG, "Invalid webhook URL.")
                return@execute
            }

            val serverLink = preferences
                .getString("private_server", null)
                ?.trim()

            val profileLink = preferences
                .getString("profile_link", null)
                ?.trim()

            val timestamp = Instant.now().epochSecond

            val normalizedName = biome.name
                .trim()
                .uppercase(Locale.ROOT)

            val color = biomeColors[normalizedName] ?: 0x777777

            // Exact title pattern used by Biome Forward.
            val title = "Biome $event - ${biome.name}"

            val description = buildString {

                append("**Biome:** ${biome.name}\n")

                // Discord displays local time automatically.
                append(
                    "**Time:** <t:$timestamp:T> " +
                    "(<t:$timestamp:R>)\n\n"
                )

                append("🔗 **Private Server:** ")

                append(
                    if (serverLink.isNullOrBlank()) {
                        "Not configured"
                    } else {
                        "[Join Server]($serverLink)"
                    }
                )

                append("\n")

                append("👤 **Found by:** ")

                append(
                    if (profileLink.isNullOrBlank()) {
                        "Not configured"
                    } else {
                        "[View Profile]($profileLink)"
                    }
                )
            }

            val embed = JSONObject().apply {

                put("title", title)
                put("description", description)
                put("color", color)

                put(
                    "footer",
                    JSONObject().put(
                        "text",
                        FOOTER
                    )
                )

                put("timestamp", Instant.now().toString())

                // Biome image from Roblox Rich Presence.
                biome.assetId?.let { assetId ->

                    val imageUrl =
                        "https://www.roblox.com/asset-thumbnail/image" +
                        "?assetId=$assetId" +
                        "&width=420" +
                        "&height=420" +
                        "&format=png"

                    put(
                        "thumbnail",
                        JSONObject().put(
                            "url",
                            imageUrl
                        )
                    )
                }
            }

            val payload = JSONObject().apply {
                put(
                    "embeds",
                    JSONArray().put(embed)
                )
            }

            var connection: HttpURLConnection? = null

            try {

                connection = URL(webhook)
                    .openConnection() as HttpURLConnection

                connection.requestMethod = "POST"
                connection.connectTimeout = 15000
                connection.readTimeout = 15000
                connection.doOutput = true

                connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=UTF-8"
                )

                connection.outputStream.use { output ->
                    output.write(
                        payload.toString().toByteArray(
                            Charsets.UTF_8
                        )
                    )
                }

                val responseCode = connection.responseCode

                if (responseCode !in 200..299) {

                    val errorBody = connection.errorStream
                        ?.bufferedReader()
                        ?.use { it.readText() }

                    Log.e(
                        TAG,
                        "Discord HTTP $responseCode: $errorBody"
                    )

                } else {

                    Log.i(
                        TAG,
                        "Notification sent: $title"
                    )
                }

            } catch (e: Exception) {

                Log.e(
                    TAG,
                    "Failed to send Discord notification.",
                    e
                )

            } finally {
                connection?.disconnect()
            }
        }
    }
}
