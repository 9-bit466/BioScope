
package com.bioscope.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingButtonService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var container: FrameLayout
    private lateinit var mainButton: ImageView
    private lateinit var menu: LinearLayout
    private lateinit var biomeStatus: TextView
    private lateinit var testStatus: TextView
    private lateinit var startStopButton: TextView
    private lateinit var params: WindowManager.LayoutParams

    private lateinit var logcatClient: ShizukuLogcatClient
    private lateinit var webhookSender: DiscordWebhookSender
    private lateinit var routeRecorder: RouteRecorder

    private val handler = Handler(Looper.getMainLooper())
    private val visualCalibrator = VisualCalibrator()

    private var menuOpen = false
    private var monitoring = false
    private var currentBiome: DetectedBiome? = null

    private var fishRouteRunning = false
    private var routeStep = 0
    private var diagnosisRunning = false
    private var routeRecording = false

    private var activeRoute = listOf<RouteMove>()

    private data class RouteMove(
        val name: String,
        val x: Float,
        val y: Float,
        val duration: Long,
        val jumpBefore: Boolean = false
    )

    // Rota provisória original.
    private val fishRoute = listOf(
        RouteMove("Avançando pelo gramado", 176f, 590f, 7000),
        RouteMove("Corrigindo para a esquerda", 145f, 605f, 1400),
        RouteMove("Seguindo em frente", 176f, 590f, 5500, true),
        RouteMove("Corrigindo para a direita", 207f, 605f, 1000),
        RouteMove("Aproximando do Fish Spot", 176f, 590f, 3000)
    )

    companion object {
        private const val CHANNEL_ID = "bioscope_service"
        private const val NOTIFICATION_ID = 1001
        private const val ROUTE_TAG = "BioScopeRoute"
    }

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                createNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(
                NOTIFICATION_ID,
                createNotification()
            )
        }

        windowManager =
            getSystemService(WINDOW_SERVICE) as WindowManager

        logcatClient = ShizukuLogcatClient(this)
        webhookSender = DiscordWebhookSender(this)
        routeRecorder = RouteRecorder(this)

        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            !Settings.canDrawOverlays(this)
        ) {
            stopSelf()
            return
        }

        createFloatingButton()
    }

    // =====================================================
    // NOTIFICAÇÃO
    // =====================================================

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BioScope",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "BioScope floating monitor"
            }

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val builder =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, CHANNEL_ID)
            } else {
                Notification.Builder(this)
            }

        return builder
            .setContentTitle("BioScope active")
            .setContentText("Floating monitor is running")
            .setSmallIcon(R.drawable.bioscope_icon)
            .setOngoing(true)
            .build()
    }

    // =====================================================
    // BOTÃO FLUTUANTE
    // =====================================================

    private fun createFloatingButton() {
        container = FrameLayout(this)

        mainButton = ImageView(this).apply {
            setImageResource(R.drawable.bioscope_icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(7.dp(), 7.dp(), 7.dp(), 7.dp())
            background = roundedBackground("#287A45", 100)
            elevation = 8.dp().toFloat()
            contentDescription = "Open BioScope menu"
        }

        val buttonParams = FrameLayout.LayoutParams(
            60.dp(),
            60.dp(),
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        )

        container.addView(mainButton, buttonParams)

        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            alpha = 0f
            scaleX = 0.8f
            scaleY = 0.8f
            background = roundedBackground("#292929", 18)
            setPadding(10.dp(), 10.dp(), 10.dp(), 10.dp())
            elevation = 8.dp().toFloat()
        }

        startStopButton = createToggleButton()

        menu.addView(
            startStopButton,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4.dp(), 0, 4.dp())
            }
        )

        biomeStatus = TextView(this).apply {
            text = "Biome current: waiting..."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundedBackground("#383838", 12)
            setPadding(10.dp(), 15.dp(), 10.dp(), 15.dp())
            visibility = View.GONE
            maxLines = 2
        }

        menu.addView(
            biomeStatus,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4.dp(), 0, 4.dp())
            }
        )

        testStatus = TextView(this).apply {
            text = "Fish route: ready"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundedBackground("#383838", 12)
            setPadding(10.dp(), 12.dp(), 10.dp(), 12.dp())
            visibility = View.GONE
            maxLines = 3
        }

        menu.addView(
            testStatus,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4.dp(), 0, 4.dp())
            }
        )

        addMenuOption("▶  START FISH ROUTE", "#286B9B") {
            startFishRoute()
        }

        addMenuOption("■  STOP FISH ROUTE", "#A13D3D") {
            stopFishRoute()
        }

        addMenuOption("●  GRAVAR ROTA", "#8A5A20") {
            startRouteRecording()
        }

        addMenuOption("💾  SALVAR + LOGCAT", "#287A45") {
            saveAndExportRoute()
        }

        addMenuOption("▶  REPRODUZIR ROTA", "#315A9B") {
            playSavedRoute()
        }

        addMenuOption("🔍  DIAGNÓSTICO VISUAL", "#315A9B") {
            startVisualDiagnosis()
        }

        addMenuOption("🎯  CALIBRAR TELA", "#287A45") {
            calibrateCurrentScreen()
        }

        addMenuOption("⚙  SETTINGS", "#454545") {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        }

        val menuParams = FrameLayout.LayoutParams(
            230.dp(),
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ).apply {
            topMargin = 68.dp()
        }

        container.addView(menu, menuParams)

        mainButton.setOnClickListener {
            toggleMenu()
        }

        setupDragging()

        params = WindowManager.LayoutParams(
            260.dp(),
            700.dp(),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 150
        }

        windowManager.addView(container, params)
    }

    private fun toggleMenu() {
        menuOpen = !menuOpen

        if (menuOpen) {
            menu.visibility = View.VISIBLE
            menu.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(180)
                .setInterpolator(OvershootInterpolator())
                .start()
        } else {
            menu.animate()
                .alpha(0f)
                .scaleX(0.8f)
                .scaleY(0.8f)
                .setDuration(150)
                .withEndAction {
                    menu.visibility = View.GONE
                }
                .start()
        }
    }

    // =====================================================
    // GRAVADOR DE ROTAS
    // =====================================================

    private fun startRouteRecording() {
        if (fishRouteRunning) {
            showToast("Pare a rota antes de iniciar outra gravação.")
            return
        }

        routeRecorder.startRecording(clearPrevious = true)
        routeRecording = true

        testStatus.visibility = View.VISIBLE
        testStatus.text = "Route recorder: aguardando movimentos"

        Log.i(ROUTE_TAG, "========== GRAVAÇÃO INICIADA ==========")

        showToast("Gravação iniciada. Agora inicie a Fish Route.")
    }

    private fun saveAndExportRoute() {
        if (routeRecording) {
            routeRecorder.stopRecording()
            routeRecording = false
        } else {
            routeRecorder.save()
        }

        val route = routeRecorder.getRoute()

        if (route.isEmpty()) {
            Log.w(ROUTE_TAG, "ROTA_VAZIA")
            showToast("Nenhum movimento foi gravado.")
            return
        }

        Log.i(ROUTE_TAG, "========== ROTA ORIGINAL ==========")
        Log.i(ROUTE_TAG, "TOTAL=${route.size}")

        route.forEachIndexed { index, step ->
            Log.i(
                ROUTE_TAG,
                "RouteMove(\"${step.name}\", " +
                    "${step.x}f, ${step.y}f, " +
                    "${step.duration}L, ${step.jumpBefore}),"
            )
        }

        Log.i(ROUTE_TAG, "========== FIM DA ROTA ==========")

        testStatus.visibility = View.VISIBLE
        testStatus.text = "Rota salva: ${route.size} movimentos"

        showToast("Rota salva e enviada ao Logcat.")
    }

    private fun playSavedRoute() {
        if (fishRouteRunning) {
            showToast("Uma rota já está em execução.")
            return
        }

        val saved = routeRecorder.getRoute()

        if (saved.isEmpty()) {
            showToast("Nenhuma rota salva.")
            return
        }

        val accessibility =
            BioScopeAccessibilityService.instance

        if (accessibility == null) {
            showToast("Ative BioScope Touch.")
            return
        }

        activeRoute = saved.map {
            RouteMove(
                name = it.name,
                x = it.x,
                y = it.y,
                duration = it.duration,
                jumpBefore = it.jumpBefore
            )
        }

        routeStep = 0
        fishRouteRunning = true

        testStatus.visibility = View.VISIBLE
        testStatus.text = "Reproduzindo rota salva..."

        showToast("Reproduzindo ${activeRoute.size} movimentos.")

        runNextRouteMove()
    }

    // =====================================================
    // DIAGNÓSTICO VISUAL
    // =====================================================

    private fun startVisualDiagnosis() {
        if (diagnosisRunning) {
            showToast("Diagnóstico já está em andamento.")
            return
        }

        val accessibility =
            BioScopeAccessibilityService.instance

        if (accessibility == null) {
            showToast("Ative BioScope Touch nas configurações.")
            return
        }

        diagnosisRunning = true
        testStatus.visibility = View.VISIBLE
        testStatus.text = "Diagnóstico: analisando tela..."

        showToast("Analisando tela do Roblox...")

        hideOverlayForCapture {
            accessibility.diagnoseScreen(
                onResult = { report ->
                    handler.post {
                        restoreOverlay()
                        diagnosisRunning = false

                        Log.d("BioScopeDiagnostic", report)

                        testStatus.text = "Diagnóstico concluído!"
                        showToast("Diagnóstico concluído! Consulte o Logcat.")
                    }
                },
                onError = { error ->
                    handler.post {
                        restoreOverlay()
                        diagnosisRunning = false

                        Log.e("BioScopeDiagnostic", error)

                        testStatus.text = "Diagnóstico: erro"
                        showToast("Erro no diagnóstico: $error")
                    }
                }
            )
        }
    }

    // =====================================================
    // CALIBRAÇÃO VISUAL
    // =====================================================

    private fun calibrateCurrentScreen() {
        if (diagnosisRunning) {
            showToast("Aguarde a análise atual.")
            return
        }

        val accessibility =
            BioScopeAccessibilityService.instance

        if (accessibility == null) {
            showToast("Ative BioScope Touch.")
            return
        }

        diagnosisRunning = true
        testStatus.visibility = View.VISIBLE
        testStatus.text = "Calibrando elementos da tela..."

        hideOverlayForCapture {
            accessibility.recognizeScreen(
                onResult = { detectedTexts ->
                    handler.post {
                        restoreOverlay()
                        diagnosisRunning = false

                        val metrics = DisplayMetrics()

                        @Suppress("DEPRECATION")
                        windowManager.defaultDisplay.getRealMetrics(metrics)

                        visualCalibrator.calibrate(
                            screenTexts = detectedTexts,
                            screenWidth = metrics.widthPixels,
                            screenHeight = metrics.heightPixels
                        )

                        val elements = listOf(
                            "fish",
                            "exit",
                            "close",
                            "sell",
                            "sell_all",
                            "talk",
                            "shop",
                            "confirm"
                        )

                        val found = elements.filter {
                            visualCalibrator.isCalibrated(it)
                        }

                        testStatus.text =
                            "Calibração: ${found.size}/${elements.size} elementos"

                        Log.d(
                            "BioScopeCalibration",
                            "Elementos encontrados: ${found.joinToString()}"
                        )

                        showToast(
                            "Calibração concluída: ${found.size} elementos."
                        )
                    }
                },
                onError = { error ->
                    handler.post {
                        restoreOverlay()
                        diagnosisRunning = false

                        Log.e("BioScopeCalibration", error)

                        testStatus.text = "Calibração: erro"
                        showToast("Falha na calibração.")
                    }
                }
            )
        }
    }

    // =====================================================
    // CAPTURA SEM OVERLAY
    // =====================================================

    private fun hideOverlayForCapture(onHidden: () -> Unit) {
        if (
            !::container.isInitialized ||
            !container.isAttachedToWindow
        ) {
            onHidden()
            return
        }

        menuOpen = false

        if (::menu.isInitialized) {
            menu.animate().cancel()
            menu.visibility = View.GONE
            menu.alpha = 0f
        }

        container.visibility = View.GONE

        handler.postDelayed({
            if (
                ::container.isInitialized &&
                container.isAttachedToWindow
            ) {
                onHidden()
            }
        }, 400)
    }

    private fun restoreOverlay() {
        if (!::container.isInitialized) return
        if (!container.isAttachedToWindow) return

        menuOpen = false

        if (::menu.isInitialized) {
            menu.animate().cancel()
            menu.visibility = View.GONE
            menu.alpha = 0f
        }

        container.visibility = View.VISIBLE
    }

    // =====================================================
    // TOQUES
    // =====================================================

    private fun tapGameRelative(
        xPercent: Float,
        yPercent: Float
    ): Boolean {
        val metrics = DisplayMetrics()

        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val x = metrics.widthPixels * xPercent
        val y = metrics.heightPixels * yPercent

        return tapGame(x, y)
    }

    private fun tapGame(x: Float, y: Float): Boolean {
        val accessibility =
            BioScopeAccessibilityService.instance

        if (accessibility == null) {
            showToast("BioScope Touch desconectado.")
            return false
        }

        val accepted = accessibility.tap(x, y)

        if (!accepted) {
            showToast("Não foi possível enviar o toque.")
        }

        return accepted
    }

    // =====================================================
    // FISH ROUTE - OCR
    // =====================================================

    private fun startFishRoute() {
        if (fishRouteRunning) {
            showToast("Fish route já está funcionando.")
            return
        }

        if (BioScopeAccessibilityService.instance == null) {
            showToast("Ative BioScope Touch nas configurações.")
            return
        }

        // Se não houver rota gravada, usa a rota provisória.
        val saved = routeRecorder.getRoute()

        activeRoute = if (saved.isNotEmpty()) {
            saved.map {
                RouteMove(
                    name = it.name,
                    x = it.x,
                    y = it.y,
                    duration = it.duration,
                    jumpBefore = it.jumpBefore
                )
            }
        } else {
            fishRoute
        }

        fishRouteRunning = true
        routeStep = 0

        testStatus.visibility = View.VISIBLE
        testStatus.text = "Fish route: abrindo menu Roblox..."

        showToast("Fish route iniciada!")

        if (!tapGameRelative(0.045f, 0.035f)) {
            stopFishRoute()
            return
        }

        handler.postDelayed({
            if (!fishRouteRunning) return@postDelayed

            findAndTapText(
                listOf("Respawn", "Reset Character")
            ) { found ->

                if (!fishRouteRunning) return@findAndTapText

                if (!found) {
                    stopFishRoute()
                    showToast("Botão de respawn não encontrado.")
                    return@findAndTapText
                }

                handler.postDelayed({
                    if (!fishRouteRunning) return@postDelayed

                    findAndTapText(
                        listOf("Respawn", "Reset")
                    ) { confirmed ->

                        if (!fishRouteRunning) return@findAndTapText

                        if (!confirmed) {
                            stopFishRoute()
                            showToast("Confirmação não encontrada.")
                            return@findAndTapText
                        }

                        handler.postDelayed({
                            if (!fishRouteRunning) return@postDelayed

                            testStatus.text =
                                "Fish route: abrindo livro..."

                            if (!tapGameRelative(0.06f, 0.335f)) {
                                stopFishRoute()
                                return@postDelayed
                            }

                            handler.postDelayed({
                                if (!fishRouteRunning) return@postDelayed

                                findAndTapText(
                                    listOf("Exit")
                                ) { exitFound ->

                                    if (!fishRouteRunning) {
                                        return@findAndTapText
                                    }

                                    if (!exitFound) {
                                        stopFishRoute()
                                        showToast("Exit não encontrado.")
                                        return@findAndTapText
                                    }

                                    handler.postDelayed({
                                        if (!fishRouteRunning) {
                                            return@postDelayed
                                        }

                                        testStatus.text =
                                            "Fish route: iniciando caminhada..."

                                        runNextRouteMove()
                                    }, 1000)
                                }
                            }, 1800)
                        }, 8000)
                    }
                }, 1500)
            }
        }, 1000)
    }

    // =====================================================
    // BIOSCOPE VISION - OCR
    // =====================================================

    private fun findAndTapText(
        targets: List<String>,
        attempt: Int = 1,
        maxAttempts: Int = 12,
        onFinished: (Boolean) -> Unit
    ) {
        if (!fishRouteRunning) return

        val accessibility =
            BioScopeAccessibilityService.instance

        if (accessibility == null) {
            Log.e("BioScopeVision", "Accessibility desconectado")
            onFinished(false)
            return
        }

        val targetLabel = targets.firstOrNull() ?: return

        testStatus.text =
            "Vision: procurando $targetLabel ($attempt/$maxAttempts)"

        hideOverlayForCapture {
            accessibility.recognizeScreen(
                onResult = { detectedTexts ->
                    handler.post {
                        restoreOverlay()

                        if (!fishRouteRunning) return@post

                        val found = detectedTexts.firstOrNull { line ->
                            targets.any { target ->
                                line.text.contains(
                                    target,
                                    ignoreCase = true
                                )
                            }
                        }

                        if (found == null) {
                            Log.d(
                                "BioScopeVision",
                                "Textos encontrados: ${
                                    detectedTexts.joinToString(" | ") { it.text }
                                }"
                            )

                            retryTextSearch(
                                targets,
                                attempt,
                                maxAttempts,
                                onFinished
                            )
                            return@post
                        }

                        val centerX =
                            (found.left + found.right) / 2f

                        val centerY =
                            (found.top + found.bottom) / 2f

                        Log.d(
                            "BioScopeVision",
                            "Encontrado: ${found.text} em $centerX,$centerY"
                        )

                        testStatus.text =
                            "Vision: encontrado ${found.text}"

                        if (accessibility.tap(centerX, centerY)) {
                            onFinished(true)
                        } else {
                            retryTextSearch(
                                targets,
                                attempt,
                                maxAttempts,
                                onFinished
                            )
                        }
                    }
                },
                onError = { error ->
                    handler.post {
                        restoreOverlay()

                        Log.e("BioScopeVision", "Erro OCR: $error")

                        retryTextSearch(
                            targets,
                            attempt,
                            maxAttempts,
                            onFinished
                        )
                    }
                }
            )
        }
    }

    private fun retryTextSearch(
        targets: List<String>,
        attempt: Int,
        maxAttempts: Int,
        onFinished: (Boolean) -> Unit
    ) {
        if (!fishRouteRunning) return

        if (attempt >= maxAttempts) {
            Log.e(
                "BioScopeVision",
                "Texto não encontrado: ${targets.joinToString()}"
            )

            testStatus.text =
                "Vision: texto não encontrado"

            onFinished(false)
            return
        }

        handler.postDelayed({
            if (fishRouteRunning) {
                findAndTapText(
                    targets = targets,
                    attempt = attempt + 1,
                    maxAttempts = maxAttempts,
                    onFinished = onFinished
                )
            }
        }, 800)
    }

    // =====================================================
    // MOVIMENTAÇÃO E REPRODUÇÃO
    // =====================================================

    private fun runNextRouteMove() {
        if (!fishRouteRunning) return

        if (routeStep >= activeRoute.size) {
            fishRouteRunning = false

            testStatus.text = "Fish route: rota concluída"

            if (routeRecording) {
                Log.i(
                    ROUTE_TAG,
                    "Percurso terminou. Use SALVAR + LOGCAT."
                )
            }

            showToast("Rota finalizada.")
            return
        }

        val move = activeRoute[routeStep]

        testStatus.text =
            "Fish route: ${routeStep + 1}/${activeRoute.size}\n${move.name}"

        if (move.jumpBefore) {
            if (!tapGameRelative(0.8969f, 0.8861f)) {
                stopFishRoute()
                showToast("Comando de pulo rejeitado.")
                return
            }

            handler.postDelayed({
                if (fishRouteRunning) {
                    executeRouteMove(move)
                }
            }, 400)
        } else {
            executeRouteMove(move)
        }
    }

    private fun executeRouteMove(move: RouteMove) {
        if (!fishRouteRunning) return

        val accessibility =
            BioScopeAccessibilityService.instance

        if (accessibility == null) {
            stopFishRoute()
            return
        }

        val accepted = accessibility.moveJoystick(
            move.x,
            move.y,
            move.duration
        ) { completed ->

            handler.post {
                if (!fishRouteRunning) return@post

                if (!completed) {
                    stopFishRoute()
                    testStatus.text =
                        "Fish route: falha no movimento"
                    showToast("Movimento do joystick falhou.")
                    return@post
                }

                // Registra somente os movimentos executados
                // pelo próprio BioScope.
                if (routeRecording) {
                    routeRecorder.recordMovement(
                        name = move.name,
                        x = move.x,
                        y = move.y,
                        duration = move.duration,
                        jumpBefore = move.jumpBefore
                    )

                    Log.d(
                        ROUTE_TAG,
                        "Movimento gravado: ${move.name} " +
                            "x=${move.x} y=${move.y} " +
                            "duration=${move.duration}"
                    )
                }

                routeStep++

                handler.postDelayed({
                    if (fishRouteRunning) {
                        runNextRouteMove()
                    }
                }, 350)
            }
        }

        if (!accepted) {
            stopFishRoute()
            testStatus.text =
                "Fish route: comando rejeitado"
            showToast("Não foi possível enviar o movimento.")
        }
    }

    private fun stopFishRoute() {
        if (!fishRouteRunning) {
            showToast("Nenhuma rota está funcionando.")
            return
        }

        fishRouteRunning = false

        testStatus.text =
            "Fish route: parada no passo $routeStep"

        showToast("Fish route parada.")
    }

    // =====================================================
    // BIOME MONITOR
    // =====================================================

    private fun createToggleButton(): TextView {
        return TextView(this).apply {
            text = "▶  START MONITOR"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundedBackground("#287A45", 12)
            setPadding(12.dp(), 15.dp(), 12.dp(), 15.dp())
            isClickable = true

            setOnClickListener {
                if (monitoring) {
                    stopMonitoring()
                } else {
                    startMonitoring()
                }
            }
        }
    }

    private fun updateToggleButton() {
        if (!::startStopButton.isInitialized) return

        if (monitoring) {
            startStopButton.text = "■  STOP MONITOR"
            startStopButton.background =
                roundedBackground("#A13D3D", 12)
        } else {
            startStopButton.text = "▶  START MONITOR"
            startStopButton.background =
                roundedBackground("#287A45", 12)
        }
    }

    private fun startMonitoring() {
        if (monitoring) return

        monitoring = true
        currentBiome = null

        updateToggleButton()

        biomeStatus.visibility = View.VISIBLE
        biomeStatus.text = "Biome current: waiting..."

        showToast("Conectando ao Shizuku...")

        logcatClient.connect(
            logsCallback = { logs ->
                if (!monitoring) return@connect

                val detectedBiome = logs
                    .mapNotNull {
                        BiomeDetector.detectBiomeInfo(it)
                    }
                    .lastOrNull()
                    ?: return@connect

                val previousBiome = currentBiome

                if (
                    previousBiome?.name.equals(
                        detectedBiome.name,
                        ignoreCase = true
                    )
                ) {
                    return@connect
                }

                currentBiome = detectedBiome

                handler.post {
                    biomeStatus.text =
                        "Biome current: ${detectedBiome.name}"
                }

                if (previousBiome == null) {
                    webhookSender.sendBiomeStarted(detectedBiome)
                } else {
                    webhookSender.sendBiomeEnded(previousBiome)
                    webhookSender.sendBiomeStarted(detectedBiome)
                }
            },
            errorCallback = { error ->
                handler.post {
                    monitoring = false
                    updateToggleButton()
                    showToast(error)
                }
            }
        )
    }

    private fun stopMonitoring() {
        if (!monitoring) return

        monitoring = false
        logcatClient.disconnect()
        updateToggleButton()

        biomeStatus.text =
            if (currentBiome != null) {
                "Biome current: ${currentBiome!!.name}"
            } else {
                "Biome current: stopped"
            }

        showToast("Monitor parado.")
    }

    // =====================================================
    // ARRASTAR BOTÃO FLUTUANTE
    // =====================================================

    private fun setupDragging() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moving = false

        mainButton.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moving = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY

                    if (
                        kotlin.math.abs(dx) > 8 ||
                        kotlin.math.abs(dy) > 8
                    ) {
                        moving = true

                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()

                        windowManager.updateViewLayout(
                            container,
                            params
                        )
                    }

                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!moving) view.performClick()
                    true
                }

                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
    }

    // =====================================================
    // OPÇÕES DO MENU
    // =====================================================

    private fun addMenuOption(
        label: String,
        color: String,
        action: () -> Unit
    ) {
        val option = TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundedBackground(color, 12)
            setPadding(12.dp(), 15.dp(), 12.dp(), 15.dp())
            isClickable = true

            setOnTouchListener { view, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        view.alpha = 0.6f
                        true
                    }

                    MotionEvent.ACTION_UP -> {
                        view.alpha = 1f
                        action()
                        true
                    }

                    MotionEvent.ACTION_CANCEL -> {
                        view.alpha = 1f
                        true
                    }

                    else -> true
                }
            }
        }

        menu.addView(
            option,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4.dp(), 0, 4.dp())
            }
        )
    }

    // =====================================================
    // UTILITÁRIOS
    // =====================================================

    private fun roundedBackground(
        color: String,
        radius: Int
    ): GradientDrawable {
        return GradientDrawable().apply {
            setColor(Color.parseColor(color))
            cornerRadius = radius.dp().toFloat()
        }
    }

    private fun Int.dp(): Int {
        return (this * resources.displayMetrics.density).toInt()
    }

    private fun showToast(message: String) {
        Toast.makeText(
            this,
            message,
            Toast.LENGTH_SHORT
        ).show()
    }

    // =====================================================
    // CICLO DE VIDA
    // =====================================================

    override fun onDestroy() {
        fishRouteRunning = false
        monitoring = false
        diagnosisRunning = false

        if (routeRecording && ::routeRecorder.isInitialized) {
            routeRecorder.stopRecording()
            routeRecording = false
        }

        handler.removeCallbacksAndMessages(null)

        if (::logcatClient.isInitialized) {
            logcatClient.disconnect()
        }

        if (
            ::container.isInitialized &&
            container.isAttachedToWindow
        ) {
            windowManager.removeView(container)
        }

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
