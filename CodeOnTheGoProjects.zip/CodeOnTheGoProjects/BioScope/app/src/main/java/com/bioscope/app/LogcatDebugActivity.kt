package com.bioscope.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.ScrollView
import android.widget.TextView
import android.widget.LinearLayout

class LogcatDebugActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val logs = intent.getStringArrayExtra("DEBUG_LOGS") ?: emptyArray()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(18, 18, 22))
        }

        val title = TextView(this).apply {
            text = "BioScope - Diagnóstico"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 20)
        }

        val content = TextView(this).apply {
            text = if (logs.isEmpty()) {
                "Nenhum registro contendo 'roblox' foi encontrado."
            } else {
                "Registros encontrados: ${logs.size}\n\n" +
                    logs.joinToString("\n\n")
            }
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setTextIsSelectable(true)
        }

        val scroll = ScrollView(this).apply {
            addView(content)
        }

        layout.addView(title)
        layout.addView(scroll)

        setContentView(layout)
    }
}
