package com.bioscope.app

import java.io.BufferedReader
import java.io.InputStreamReader

class LogcatUserService : ILogcatService.Stub() {

    private var previousLines = emptySet<String>()
    private var initialized = false

    // Termos que podem indicar informações do ambiente do jogo.
    private val relevantKeywords = listOf(
        "biome",
        "weather",
        "climate",
        "environment",
        "atmosphere",
        "world",
        "region",
        "zone",
        "state",
        "changed",
        "updated",
        "started",
        "ended"
    )

    @Synchronized
    override fun readRecentRobloxLogs(maxLines: Int): Array<String> {
        val output = executeLogcat(
            "-d",
            "-t",
            maxLines.coerceIn(1, 1000).toString()
        )

        previousLines = output.toSet()
        initialized = true

        return output
            .filter { isRobloxLog(it) }
            .filter { isRelevantLog(it) }
            .toTypedArray()
    }

    @Synchronized
    override fun readNewRobloxLogs(): Array<String> {
        val output = executeLogcat("-d", "-t", "1000")
        val currentLines = output.toSet()

        if (!initialized) {
            previousLines = currentLines
            initialized = true
            return emptyArray()
        }

        val newLines = output.filter { line ->
            line !in previousLines &&
                isRobloxLog(line) &&
                isRelevantLog(line)
        }

        previousLines = currentLines

        return newLines.toTypedArray()
    }

    // Identifica registros produzidos pelo Roblox.
    private fun isRobloxLog(line: String): Boolean {
        return line.contains("I Roblox") ||
                line.contains("Roblox :", ignoreCase = true)
    }

    // Procura possíveis informações sobre o ambiente do jogo.
    private fun isRelevantLog(line: String): Boolean {
        return relevantKeywords.any { keyword ->
            line.contains(keyword, ignoreCase = true)
        }
    }

    private fun executeLogcat(vararg arguments: String): List<String> {
        return try {
            val command = mutableListOf("logcat")
            command.addAll(arguments)

            val process = ProcessBuilder(command)
                .redirectErrorStream(true)
                .start()

            val output = BufferedReader(
                InputStreamReader(process.inputStream)
            ).use { reader ->
                reader.readLines()
            }

            process.waitFor()
            output

        } catch (e: Exception) {
            emptyList()
        }
    }
}
