package com.bioscope.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bioscope.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private var _binding: ActivityMainBinding? = null

    private val binding: ActivityMainBinding
        get() = checkNotNull(_binding)

    private var touchStartX = 0f
    private var touchStartY = 0f

    private val swipeThreshold = 80f

    private val macroPreferences by lazy {
        getSharedPreferences("bioscope_macro_config", MODE_PRIVATE)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->

            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                WindowInsetsCompat.Type.displayCutout()
            )

            v.setPadding(
                bars.left,
                bars.top,
                bars.right,
                bars.bottom
            )

            insets
        }

        setupMainButtons()
        setupDrawer()
        setupFolders()
        setupMacroSettings()
    }

    // BOTÕES PRINCIPAIS

    private fun setupMainButtons() {

        binding.detectorButton.setOnClickListener {
            startScope()
        }

        binding.stopButton.setOnClickListener {
            stopScope()
        }
    }

    // START PRINCIPAL

    private fun startScope() {

        if (!Settings.canDrawOverlays(this)) {

            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )

            startActivity(intent)
            return
        }

        val serviceIntent = Intent(
            this,
            FloatingButtonService::class.java
        )

        if (android.os.Build.VERSION.SDK_INT >=
            android.os.Build.VERSION_CODES.O
        ) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        Toast.makeText(
            this,
            "Botão flutuante criado!",
            Toast.LENGTH_SHORT
        ).show()
    }

    // STOP PRINCIPAL

    private fun stopScope() {

        stopService(
            Intent(this, FloatingButtonService::class.java)
        )

        Toast.makeText(
            this,
            "BioScope parado!",
            Toast.LENGTH_SHORT
        ).show()
    }

    // MENU LATERAL

    private fun setupDrawer() {

        binding.drawerOverlay.setOnClickListener {
            closeDrawer()
        }
    }

    private fun openDrawer() {

        binding.drawerOverlay.visibility = View.VISIBLE
        binding.settingsDrawer.visibility = View.VISIBLE

        binding.settingsDrawer.alpha = 0f
        binding.settingsDrawer.translationX = 80f

        binding.settingsDrawer.animate()
            .alpha(1f)
            .translationX(0f)
            .setDuration(220)
            .start()

        binding.drawerOverlay.animate()
            .alpha(1f)
            .setDuration(220)
            .start()
    }

    private fun closeDrawer() {

        binding.settingsDrawer.animate()
            .alpha(0f)
            .translationX(80f)
            .setDuration(180)
            .withEndAction {
                binding.settingsDrawer.visibility = View.GONE
            }
            .start()

        binding.drawerOverlay.animate()
            .alpha(0f)
            .setDuration(180)
            .withEndAction {
                binding.drawerOverlay.visibility = View.GONE
            }
            .start()
    }

    private fun isDrawerOpen(): Boolean {
        return binding.settingsDrawer.visibility == View.VISIBLE
    }

    // PASTAS EXPANSÍVEIS

    private fun setupFolders() {

        binding.generalHeader.setOnClickListener {

            toggleFolder(
                binding.generalOptions,
                binding.generalHeader,
                "📁 Configurações gerais"
            )
        }

        binding.advancedHeader.setOnClickListener {

            toggleFolder(
                binding.advancedOptions,
                binding.advancedHeader,
                "📁 Configurações avançadas"
            )
        }

        binding.macroHeader.setOnClickListener {

            toggleFolder(
                binding.macroOptions,
                binding.macroHeader,
                "📁 Configurações de macro"
            )
        }
    }

    private fun toggleFolder(
        selectedOptions: View,
        selectedHeader: android.widget.TextView,
        title: String
    ) {

        val shouldOpen =
            selectedOptions.visibility != View.VISIBLE

        binding.generalOptions.visibility = View.GONE
        binding.advancedOptions.visibility = View.GONE
        binding.macroOptions.visibility = View.GONE

        binding.generalHeader.text =
            "📁 Configurações gerais  ﹀"

        binding.advancedHeader.text =
            "📁 Configurações avançadas  ﹀"

        binding.macroHeader.text =
            "📁 Configurações de macro  ﹀"

        if (shouldOpen) {

            selectedOptions.visibility = View.VISIBLE
            selectedHeader.text = "$title  ︿"
        }
    }

    // CONFIGURAÇÕES DE MACRO

    private fun setupMacroSettings() {

        // CARREGAR CONFIGURAÇÕES SALVAS

        binding.macroWebhookInput.setText(
            macroPreferences.getString("webhook", "")
        )

        binding.macroPrivateServerInput.setText(
            macroPreferences.getString("private_server", "")
        )

        binding.macroProfileInput.setText(
            macroPreferences.getString("profile_link", "")
        )

        // CARREGAR CONFIGURAÇÕES DE PESCA

        binding.automaticFishingCheckbox.isChecked =
            macroPreferences.getBoolean("automatic_fishing", false)

        binding.fishCyclesInput.setText(
            macroPreferences.getInt("fish_cycles", 1).toString()
        )

        binding.salesCyclesInput.setText(
            macroPreferences.getInt("sales_cycles", 1).toString()
        )

        // SALVAR CONFIGURAÇÕES

        binding.saveMacroButton.setOnClickListener {

            val webhook =
                binding.macroWebhookInput.text.toString().trim()

            val privateServer =
                binding.macroPrivateServerInput.text.toString().trim()

            val profileLink =
                binding.macroProfileInput.text.toString().trim()

            val automaticFishing =
                binding.automaticFishingCheckbox.isChecked

            val fishCycles =
                binding.fishCyclesInput.text.toString()
                    .toIntOrNull()?.coerceAtLeast(0) ?: 1

            val salesCycles =
                binding.salesCyclesInput.text.toString()
                    .toIntOrNull()?.coerceAtLeast(0) ?: 1

            // Atualizar campos caso estejam vazios ou inválidos

            binding.fishCyclesInput.setText(fishCycles.toString())
            binding.salesCyclesInput.setText(salesCycles.toString())

            macroPreferences.edit()
                .putString("webhook", webhook)
                .putString("private_server", privateServer)
                .putString("profile_link", profileLink)
                .putBoolean("automatic_fishing", automaticFishing)
                .putInt("fish_cycles", fishCycles)
                .putInt("sales_cycles", salesCycles)
                .apply()

            Toast.makeText(
                this,
                "Configurações de macro salvas!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // GESTOS

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {

        when (event.action) {

            MotionEvent.ACTION_DOWN -> {

                touchStartX = event.rawX
                touchStartY = event.rawY
            }

            MotionEvent.ACTION_UP -> {

                val deltaX = event.rawX - touchStartX
                val deltaY = event.rawY - touchStartY

                val horizontalSwipe =
                    kotlin.math.abs(deltaX) > swipeThreshold &&
                    kotlin.math.abs(deltaX) > kotlin.math.abs(deltaY)

                if (horizontalSwipe) {

                    if (!isDrawerOpen() && deltaX < 0) {
                        openDrawer()
                    } else if (isDrawerOpen() && deltaX > 0) {
                        closeDrawer()
                    }
                }
            }
        }

        return super.dispatchTouchEvent(event)
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
