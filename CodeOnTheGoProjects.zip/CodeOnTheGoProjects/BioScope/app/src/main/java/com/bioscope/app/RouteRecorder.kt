
package com.bioscope.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class RouteStep(
    val name: String,
    val x: Float,
    val y: Float,
    val duration: Long,
    val jumpBefore: Boolean = false
)

class RouteRecorder(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("bioscope_routes", Context.MODE_PRIVATE)

    private val route = mutableListOf<RouteStep>()

    var isRecording = false
        private set

    init {
        load()
    }

    @Synchronized
    fun startRecording(clearPrevious: Boolean = true) {
        if (clearPrevious) {
            route.clear()
            save()
        }
        isRecording = true
    }

    @Synchronized
    fun recordMovement(
        name: String,
        x: Float,
        y: Float,
        duration: Long,
        jumpBefore: Boolean = false
    ) {
        if (!isRecording || duration <= 0) return

        route.add(
            RouteStep(
                name = name,
                x = x,
                y = y,
                duration = duration,
                jumpBefore = jumpBefore
            )
        )

        save()
    }

    @Synchronized
    fun stopRecording(): List<RouteStep> {
        isRecording = false
        save()
        return route.toList()
    }

    @Synchronized
    fun getRoute(): List<RouteStep> {
        return route.toList()
    }

    @Synchronized
    fun clearRoute() {
        route.clear()
        save()
    }

    @Synchronized
    fun save() {
        val array = JSONArray()

        route.forEach { step ->
            val item = JSONObject()
            item.put("name", step.name)
            item.put("x", step.x.toDouble())
            item.put("y", step.y.toDouble())
            item.put("duration", step.duration)
            item.put("jumpBefore", step.jumpBefore)
            array.put(item)
        }

        prefs.edit()
            .putString("saved_route", array.toString())
            .apply()
    }

    @Synchronized
    private fun load() {
        route.clear()

        val saved = prefs.getString("saved_route", null)
            ?: return

        try {
            val array = JSONArray(saved)

            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)

                route.add(
                    RouteStep(
                        name = item.optString("name", "Movimento"),
                        x = item.optDouble("x", 176.0).toFloat(),
                        y = item.optDouble("y", 590.0).toFloat(),
                        duration = item.optLong("duration", 1000L),
                        jumpBefore = item.optBoolean("jumpBefore", false)
                    )
                )
            }
        } catch (_: Exception) {
            route.clear()
        }
    }
}
