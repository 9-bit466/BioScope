package com.bioscope.app

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import rikka.shizuku.Shizuku
import java.util.concurrent.atomic.AtomicBoolean

class ShizukuLogcatClient(context: Context) {

    private val appContext = context.applicationContext
    private var remote: ILogcatService? = null

    private var onLogs: ((Array<String>) -> Unit)? = null
    private var onError: ((String) -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)

    private var bound = false

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!running.get()) return

            Thread {
                try {
                    val logs = remote?.readNewRobloxLogs()
                        ?: emptyArray()

                    if (running.get() && logs.isNotEmpty()) {
                        handler.post {
                            if (running.get()) {
                                onLogs?.invoke(logs)
                            }
                        }
                    }

                } catch (e: Exception) {
                    handler.post {
                        onError?.invoke(
                            "Erro ao consultar registros: ${e.message}"
                        )
                    }
                }

                if (running.get()) {
                    handler.postDelayed(this, 2000)
                }
            }.start()
        }
    }

    private val args = Shizuku.UserServiceArgs(
        ComponentName(appContext, LogcatUserService::class.java)
    )
        .daemon(false)
        .tag("bioscope-logcat")
        .processNameSuffix("bioscope_logcat")
        .version(1)

    private val connection = object : ServiceConnection {

        override fun onServiceConnected(
            name: ComponentName?,
            service: IBinder?
        ) {
            if (service == null) {
                reportError("Binder remoto vazio.")
                return
            }

            remote = ILogcatService.Stub.asInterface(service)

            try {
                remote?.readRecentRobloxLogs(500)
                running.set(true)
                handler.post(pollRunnable)
            } catch (e: Exception) {
                reportError("Erro ao iniciar leitura: ${e.message}")
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null
            running.set(false)
            handler.removeCallbacks(pollRunnable)
            reportError("Conexão Shizuku perdida.")
        }
    }

    fun connect(
        logsCallback: (Array<String>) -> Unit,
        errorCallback: (String) -> Unit
    ) {
        onLogs = logsCallback
        onError = errorCallback

        if (bound || running.get()) return

        if (!Shizuku.pingBinder()) {
            reportError("Shizuku não está iniciado.")
            return
        }

        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            reportError("BioScope não tem autorização do Shizuku.")
            return
        }

        try {
            bound = true
            Shizuku.bindUserService(args, connection)
        } catch (e: Exception) {
            bound = false
            reportError("Falha ao conectar: ${e.message}")
        }
    }

    private fun reportError(message: String) {
        handler.post {
            onError?.invoke(message)
        }
    }

    fun disconnect() {
        running.set(false)
        handler.removeCallbacks(pollRunnable)

        try {
            if (bound) {
                Shizuku.unbindUserService(args, connection, true)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        bound = false
        remote = null
    }
}
