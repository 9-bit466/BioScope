package com.bioscope.app

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuManager {

    private const val REQUEST_CODE = 1001

    enum class Status {
        NOT_RUNNING,
        NOT_AUTHORIZED,
        AUTHORIZED,
        UNSUPPORTED,
        ERROR
    }

    fun checkStatus(): Status {
        return try {
            if (Shizuku.isPreV11()) {
                return Status.UNSUPPORTED
            }

            if (!Shizuku.pingBinder()) {
                return Status.NOT_RUNNING
            }

            if (
                Shizuku.checkSelfPermission() ==
                PackageManager.PERMISSION_GRANTED
            ) {
                Status.AUTHORIZED
            } else {
                Status.NOT_AUTHORIZED
            }

        } catch (e: Exception) {
            Status.ERROR
        }
    }

    fun requestPermission() {
        try {
            if (!Shizuku.pingBinder()) return

            if (
                Shizuku.checkSelfPermission() ==
                PackageManager.PERMISSION_GRANTED
            ) return

            Shizuku.requestPermission(REQUEST_CODE)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
