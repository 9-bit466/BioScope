package com.bioscope.app

import android.graphics.Rect
import android.util.Log

data class CalibratedElement(
    val name: String,
    val x: Float,
    val y: Float,
    val bounds: Rect
)

class VisualCalibrator {

    private val targets = mapOf(
        "fish" to listOf("pescar", "pesca"),
        "exit" to listOf("sair"),
        "close" to listOf("x"),
        "sell" to listOf("vender"),
        "sell_all" to listOf("vender todos"),
        "talk" to listOf("falar"),
        "shop" to listOf("abrir loja"),
        "confirm" to listOf("ok", "confirmar")
    )

    private val calibrated =
        mutableMapOf<String, CalibratedElement>()

    fun calibrate(
        screenTexts: List<BioScopeAccessibilityService.ScreenText>,
        screenWidth: Int,
        screenHeight: Int
    ) {
        calibrated.clear()

        if (screenWidth <= 0 || screenHeight <= 0) {
            Log.e(
                "BioScopeCalibration",
                "Resolução inválida"
            )
            return
        }

        for ((name, variations) in targets) {

            val match = screenTexts.firstOrNull { line ->
                variations.any { target ->
                    line.text.contains(
                        target,
                        ignoreCase = true
                    )
                }
            }

            if (match != null) {

                val centerX =
                    (match.left + match.right) / 2f

                val centerY =
                    (match.top + match.bottom) / 2f

                calibrated[name] = CalibratedElement(
                    name = name,
                    x = centerX / screenWidth,
                    y = centerY / screenHeight,
                    bounds = Rect(
                        match.left,
                        match.top,
                        match.right,
                        match.bottom
                    )
                )

                Log.d(
                    "BioScopeCalibration",
                    "$name detectado: $centerX, $centerY"
                )
            }
        }

        Log.d(
            "BioScopeCalibration",
            "Calibração concluída: ${calibrated.size}/${targets.size}"
        )
    }

    fun get(name: String): CalibratedElement? {
        return calibrated[name]
    }

    fun getScreenPosition(
        name: String,
        screenWidth: Int,
        screenHeight: Int
    ): Pair<Float, Float>? {

        val element = calibrated[name] ?: return null

        return Pair(
            element.x * screenWidth,
            element.y * screenHeight
        )
    }

    fun isCalibrated(name: String): Boolean {
        return calibrated.containsKey(name)
    }

    fun clear() {
        calibrated.clear()
    }
}
